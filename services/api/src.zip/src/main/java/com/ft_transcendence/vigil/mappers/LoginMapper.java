package com.ft_transcendence.vigil.mappers;

import com.ft_transcendence.vigil.domain.dtos.LoginDto;
import com.ft_transcendence.vigil.domain.entities.User;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
@Mapper(componentModel = "spring")
public interface LoginMapper extends StandardMapper<User, LoginDto> {
    @Mapping(target = "password", source = "passwordHash")
    LoginDto map(User user);
    @Mapping(target = "passwordHash", source = "password")
    User map(LoginDto loginDto);
}