package com.ft_transcendence.vigil.exceptions;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DuplicatedResourcesException extends RuntimeException{
    public DuplicatedResourcesException(String message)
    {
        super(message);
    }
}
