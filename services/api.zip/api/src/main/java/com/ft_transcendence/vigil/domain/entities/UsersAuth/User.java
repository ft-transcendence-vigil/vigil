package com.ft_transcendence.vigil.domain.entities.UsersAuth;
import jakarta.persistence.*;
// import jakarta.validation.constraints.Email;      //old code — input validation moved to DTOs
// import jakarta.validation.constraints.NotBlank;   //old code — input validation moved to DTOs
import lombok.*;

import java.util.List;
import java.util.UUID;
@Getter
@Setter
@Builder
@Entity()
@Table(name = "users")
@NoArgsConstructor
@AllArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(unique = true,nullable = false)
    private String email;

    @Column(nullable = false)
    private String passwordHash;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private Role role;

    @OneToMany(mappedBy = "user", cascade = {CascadeType.PERSIST,CascadeType.MERGE,CascadeType.REMOVE} ,orphanRemoval = true)
    private List<Session> sessions;

    @OneToMany(mappedBy = "user", cascade = {CascadeType.PERSIST,CascadeType.MERGE,CascadeType.REMOVE} ,orphanRemoval = true)
    private List<RefreshToken> refreshTokens;
}
